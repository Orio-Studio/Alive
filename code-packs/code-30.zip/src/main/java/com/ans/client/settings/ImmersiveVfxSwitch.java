package com.ans.client.settings;

import com.ans.Ans;
import com.ans.client.vn.VnReflect;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

/**
 * The on/off switch for ImmersiveVFX, which travels inside this mod. Turning it off puts every ImmersiveVFX option back to
 * the plain game look and remembers what was set; turning it on puts those options back. Everything is looked up by name,
 * so the switch does nothing (and is hidden) when ImmersiveVFX is not there.
 */
public final class ImmersiveVfxSwitch {
   private static final String CONFIG = "com.shinyflvres.immersivevfx.config.ImmersiveVFXConfig";
   private static final String SETTINGS = "com.shinyflvres.immersivevfx.VfxSettings";
   private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("alive-immersivevfx.json");
   /** The plain-game value of each ImmersiveVFX choice, by the name of its type. */
   private static final Map<String, String> PLAIN = Map.of(
      "FogMode", "OFF", "SkyMode", "VANILLA", "ParticleStyle", "VANILLA", "ParticleRate", "NONE",
      "WaterColors", "VANILLA", "CloudRendering", "FANCY", "ShadowMode", "NORMAL"
   );

   private ImmersiveVfxSwitch() {
   }

   public static boolean available() {
      try {
         Class.forName(CONFIG);
         return true;
      } catch (ReflectiveOperationException | LinkageError ex) {
         return false;
      }
   }

   private static JsonObject read() {
      try {
         if (Files.exists(FILE)) {
            return JsonParser.parseString(Files.readString(FILE, StandardCharsets.UTF_8)).getAsJsonObject();
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Could not read {}: {}", FILE, ex.toString());
      }

      return new JsonObject();
   }

   private static void write(JsonObject o) {
      try {
         Files.writeString(FILE, new Gson().toJson(o), StandardCharsets.UTF_8);
      } catch (IOException ex) {
         Ans.LOGGER.warn("[ans] Could not write {}: {}", FILE, ex.toString());
      }
   }

   /** On unless it was turned off here. */
   public static boolean enabled() {
      JsonObject o = read();
      return !o.has("enabled") || o.get("enabled").getAsBoolean();
   }

   public static void set(boolean on) {
      if (!available() || on == enabled()) {
         return;
      }

      try {
         Class<?> cfg = Class.forName(CONFIG);
         JsonObject o = read();
         JsonObject saved = o.has("saved") ? o.getAsJsonObject("saved") : new JsonObject();
         for (Field f : cfg.getFields()) {
            if (!Modifier.isStatic(f.getModifiers())) {
               continue;
            }

            Object value = f.get(null);
            if (value == null || !value.getClass().getName().contains("ModConfigSpec")) {
               continue;
            }

            String type = value.getClass().getSimpleName();
            Object current = VnReflect.invoke(value, "get");
            if (!on) {
               if (type.equals("BooleanValue") && Boolean.TRUE.equals(current)) {
                  saved.addProperty(f.getName(), true);
                  VnReflect.invoke(value, "set", Boolean.FALSE);
               } else if (type.equals("EnumValue") && current instanceof Enum<?> e) {
                  String plain = PLAIN.get(e.getDeclaringClass().getSimpleName());
                  if (plain != null && !plain.equals(e.name())) {
                     saved.addProperty(f.getName(), e.name());
                     for (Object c : e.getDeclaringClass().getEnumConstants()) {
                        if (((Enum<?>)c).name().equals(plain)) {
                           VnReflect.invoke(value, "set", c);
                        }
                     }
                  }
               }
            } else if (saved.has(f.getName())) {
               if (type.equals("BooleanValue")) {
                  VnReflect.invoke(value, "set", Boolean.TRUE);
               } else if (type.equals("EnumValue") && current instanceof Enum<?> e) {
                  for (Object c : e.getDeclaringClass().getEnumConstants()) {
                     if (((Enum<?>)c).name().equals(saved.get(f.getName()).getAsString())) {
                        VnReflect.invoke(value, "set", c);
                     }
                  }
               }
            }
         }

         Object spec = null;
         try {
            spec = cfg.getField("SPEC").get(null);
         } catch (NoSuchFieldException ex) {
            // the config file is then saved by ImmersiveVFX itself
         }

         VnReflect.invoke(spec, "save");
         cfg.getMethod("apply").invoke(null);
         Class.forName(SETTINGS).getMethod("changed").invoke(null);
         o.addProperty("enabled", on);
         o.add("saved", on ? new JsonObject() : saved);
         write(o);
      } catch (ReflectiveOperationException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Could not switch ImmersiveVFX: {}", ex.toString());
      }
   }
}
