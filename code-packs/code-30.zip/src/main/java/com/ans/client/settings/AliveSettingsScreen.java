package com.ans.client.settings;

import com.ans.Ans;
import com.ans.client.vn.VnClock;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * The Alive settings screen (default key K): a photo-mode style layout. A panel on the left with tabs and rows of
 * settings (switches, choices and sliders), the game visible on the right, and a bar at the bottom with the time of day
 * and the weather. Everything is drawn from plain rectangles and text.
 */
public final class AliveSettingsScreen extends Screen {
   private static final String[] TABS = {"Actions", "Villagers", "Gear", "Effects", "Display"};
   private static final int ROW = 15;
   private static final int YELLOW = 0xFFF2B01E;
   private static final int WHITE = 0xFFFFFFFF;
   private static final int GRAY = 0xFFB0B0B0;
   private static final int[][] SKY = {{0, 16, 20, 58}, {5, 16, 20, 58}, {6, 226, 130, 70}, {8, 110, 170, 224}, {16, 110, 170, 224}, {18, 214, 100, 64}, {20, 48, 48, 90}, {24, 16, 20, 58}};
   private static final String[] WEATHER = {"clear", "rain", "thunder"};

   private static List<int[]> earth;
   private static int earthW = 1;
   private static int earthH = 1;

   private record Row(int kind, String label, String tip, AnsSettings.Setting setting) {
   }

   private record Hit(int x, int y, int w, int h, IntConsumer action) {
   }

   private final Screen parent;
   private final List<Hit> hits = new ArrayList<>();
   private int tab;
   private int first;
   private int mx;
   private int my;
   private String hint = "";

   public AliveSettingsScreen(Screen parent) {
      super(Component.literal("Alive"));
      this.parent = parent;
   }

   private static synchronized void loadEarth() {
      if (earth != null) {
         return;
      }

      List<int[]> runs = new ArrayList<>();
      try (InputStream in = AliveSettingsScreen.class.getResourceAsStream("/assets/ans_ui/earth.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
         earthW = o.get("w").getAsInt();
         earthH = o.get("h").getAsInt();
         JsonArray pal = o.getAsJsonArray("palette");
         int y = 0;
         for (JsonElement rowEl : o.getAsJsonArray("rows")) {
            int x = 0;
            for (JsonElement runEl : rowEl.getAsJsonArray()) {
               JsonArray run = runEl.getAsJsonArray();
               int len = run.get(1).getAsInt();
               runs.add(new int[]{x, y, len, Integer.parseInt(pal.get(run.get(0).getAsInt()).getAsString(), 16)});
               x += len;
            }

            y++;
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Settings background could not be loaded: {}", ex.toString());
      }

      earth = runs;
   }

   private int panelWidth() {
      return Math.max(236, Math.min(300, this.width * 26 / 100));
   }

   // ------------------------------------------------------------------------------------------------ rows

   private static int tabOf(AnsSettings.Setting s) {
      String id = s.id();
      if (id.endsWith(":villagernews") || id.endsWith(":villagerstyle") || id.endsWith(":vnglance") || id.endsWith(":vnsubtitles")
         || id.endsWith(":vnchatter") || id.endsWith(":vnrare") || id.endsWith(":vnspecial")) {
         return 1;
      }

      if (id.endsWith(":smxcbjxh") || id.endsWith(":smqqewgw") || id.endsWith(":smlrwjip") || id.endsWith(":smdtdctq") || id.endsWith(":mowakw")) {
         return 2;
      }

      return id.endsWith(":a13data") ? 3 : 0;
   }

   private List<Row> rows() {
      List<Row> out = new ArrayList<>();
      for (AnsSettings.Setting s : AnsSettings.all()) {
         if (tabOf(s) == this.tab) {
            String[] label = s.label();
            out.add(new Row(s.toggle() ? 0 : 1, label[0], label.length > 1 ? label[1] : "", s));
         }
      }

      if (this.tab == 3 && ImmersiveVfxSwitch.available()) {
         out.add(new Row(5, "Immersive VFX", "Fog, sky, light, water and particle effects of ImmersiveVFX. Off brings back the plain game look.", null));
      }

      if (this.tab == 4) {
         out.add(new Row(2, "Field of view", "How wide the picture is.", null));
      }

      return out;
   }

   // ------------------------------------------------------------------------------------------------ drawing helpers

   private void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
      g.centeredText(this.font, Component.literal(s), x + this.font.width(s) / 2, y, color);
   }

   private void textRight(GuiGraphicsExtractor g, String s, int right, int y, int color) {
      g.centeredText(this.font, Component.literal(s), right - this.font.width(s) / 2, y, color);
   }

   private String fit(String s, int max) {
      if (this.font.width(s) <= max) {
         return s;
      }

      String t = s;
      while (t.length() > 1 && this.font.width(t + "...") > max) {
         t = t.substring(0, t.length() - 1);
      }

      return t + "...";
   }

   private static int sky(double hour, int channel) {
      for (int i = 1; i < SKY.length; i++) {
         if (hour <= SKY[i][0]) {
            double t = (hour - SKY[i - 1][0]) / Math.max(1.0, SKY[i][0] - SKY[i - 1][0]);
            return (int)(SKY[i - 1][channel] + (SKY[i][channel] - SKY[i - 1][channel]) * t);
         }
      }

      return SKY[SKY.length - 1][channel];
   }

   private void drawEarth(GuiGraphicsExtractor g, int w, int h) {
      loadEarth();
      double scale = Math.max((double)w / earthW, (double)h / earthH);
      int ox = (int)((w - earthW * scale) / 2.0);
      int oy = (int)((h - earthH * scale) / 2.0);
      for (int[] run : earth) {
         int x0 = ox + (int)Math.round(run[0] * scale);
         int x1 = ox + (int)Math.round((run[0] + run[2]) * scale);
         int y0 = oy + (int)Math.round(run[1] * scale);
         int y1 = oy + (int)Math.round((run[1] + 1) * scale);
         if (x0 >= w || y0 >= h || x1 <= 0 || y1 <= 0) {
            continue;
         }

         g.fill(Math.max(0, x0), Math.max(0, y0), Math.min(w, x1), Math.min(h, y1), 0xFF000000 | run[3]);
      }
   }

   private void button(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, boolean primary, IntConsumer action) {
      boolean over = this.mx >= x && this.mx < x + w && this.my >= y && this.my < y + h;
      g.fill(x, y, x + w, y + h, primary ? (over ? 0xFFFFC83A : YELLOW) : (over ? 0xFF4A4A4A : 0xFF2E2E2E));
      g.centeredText(this.font, Component.literal(label), x + w / 2, y + (h - 8) / 2, primary ? 0xFF202020 : WHITE);
      this.hits.add(new Hit(x, y, w, h, action));
   }

   // ------------------------------------------------------------------------------------------------ the screen

   @Override
   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
      this.mx = mouseX;
      this.my = mouseY;
      this.hits.clear();
      this.hint = "";
      Minecraft mc = Minecraft.getInstance();
      int pw = this.panelWidth();
      // the left panel: the Earth picture, dimmed
      this.drawEarth(g, pw, this.height);
      g.fill(0, 0, pw, this.height, 0xB4000000);

      // tabs
      int tx = 6;
      for (int i = 0; i < TABS.length; i++) {
         int w = this.font.width(TABS[i]) + 10;
         final int index = i;
         boolean active = i == this.tab;
         boolean over = mouseX >= tx && mouseX < tx + w && mouseY >= 6 && mouseY < 20;
         g.fill(tx, 6, tx + w, 20, active ? YELLOW : over ? 0xFF4A4A4A : 0xC0101010);
         g.centeredText(this.font, Component.literal(TABS[i]), tx + w / 2, 9, active ? 0xFF202020 : WHITE);
         this.hits.add(new Hit(tx, 6, w, 14, x -> {
            this.tab = index;
            this.first = 0;
         }));
         tx += w + 2;
      }

      // rows
      List<Row> rows = this.rows();
      int visible = Math.max(1, (this.height - 30 - 46) / ROW);
      this.first = Math.max(0, Math.min(this.first, Math.max(0, rows.size() - visible)));
      int ctrl = pw - 8 - 130;
      int y = 28;
      for (int i = this.first; i < rows.size() && i < this.first + visible; i++) {
         Row r = rows.get(i);
         boolean over = mouseX >= 4 && mouseX < pw - 4 && mouseY >= y && mouseY < y + ROW;
         if (over) {
            g.fill(4, y, pw - 4, y + ROW - 1, 0x40FFFFFF);
            this.hint = r.tip();
         }

         this.text(g, this.fit(r.label(), ctrl - 14), 8, y + 3, WHITE);
         this.drawControl(g, mc, r, ctrl, y, rows.size());
         y += ROW;
      }

      if (this.first > 0) {
         this.textRight(g, "^", pw - 6, 24, GRAY);
      }

      if (this.first + visible < rows.size()) {
         this.textRight(g, "v", pw - 6, this.height - 50, GRAY);
      }

      // hint, and the two buttons at the bottom of the panel
      if (!this.hint.isEmpty()) {
         this.text(g, this.fit(this.hint, pw - 16), 8, this.height - 38, GRAY);
      }

      this.button(g, 6, this.height - 22, 74, 16, "Reset Tab", false, x -> this.resetTab());
      this.button(g, pw - 6 - 70, this.height - 22, 70, 16, "Done", true, x -> this.onClose());

      this.drawBottomBar(g, mc, pw);
   }

   private void drawControl(GuiGraphicsExtractor g, Minecraft mc, Row r, int ctrl, int y, int total) {
      AnsSettings.Setting s = r.setting();
      switch (r.kind()) {
         case 0 -> {
            boolean on = Boolean.parseBoolean(s.value());
            this.onOffBox(g, ctrl + 96, y, on, x -> AnsSettings.set(s, Boolean.toString(!Boolean.parseBoolean(s.value())), true));
         }
         case 5 -> this.onOffBox(g, ctrl + 96, y, ImmersiveVfxSwitch.enabled(), x -> ImmersiveVfxSwitch.set(!ImmersiveVfxSwitch.enabled()));
         case 1 -> {
            List<String> options = s.options();
            int index = Math.max(0, options.indexOf(s.value()));
            g.fill(ctrl, y + 1, ctrl + 130, y + ROW - 2, 0xFF2A2A2A);
            this.text(g, "<", ctrl + 3, y + 3, YELLOW);
            this.textRight(g, ">", ctrl + 128, y + 3, YELLOW);
            g.centeredText(this.font, Component.literal(this.fit(s.optionLabel(s.value()), 100)), ctrl + 65, y + 3, WHITE);
            this.hits.add(new Hit(ctrl, y, 130, ROW, x -> {
               int step = x < ctrl + 28 ? -1 : 1;
               AnsSettings.set(s, options.get(Math.floorMod(index + step, options.size())), true);
            }));
         }
         case 2 -> {
            int fov = mc.options.fov().get();
            this.slider(g, ctrl, y, (fov - 30) / 80.0, Integer.toString(fov), x -> {
               int v = 30 + (int)Math.round(Math.max(0.0, Math.min(1.0, (x - ctrl) / 96.0)) * 80.0);
               mc.options.fov().set(v);
               mc.options.save();
            });
         }
         default -> {
         }
      }
   }

   private void onOffBox(GuiGraphicsExtractor g, int x, int y, boolean on, IntConsumer action) {
      g.fill(x, y + 2, x + 34, y + ROW - 3, 0xFF2A2A2A);
      g.centeredText(this.font, Component.literal(on ? "On" : "Off"), x + 17, y + 3, on ? YELLOW : GRAY);
      this.hits.add(new Hit(x, y, 34, ROW, action));
   }

   private void slider(GuiGraphicsExtractor g, int x, int y, double fraction, String value, IntConsumer action) {
      int cy = y + ROW / 2 - 1;
      g.fill(x, cy, x + 96, cy + 2, 0xFF666666);
      int filled = (int)Math.round(Math.max(0.0, Math.min(1.0, fraction)) * 96.0);
      g.fill(x, cy, x + filled, cy + 2, YELLOW);
      g.fill(x + filled - 1, cy - 3, x + filled + 2, cy + 5, YELLOW);
      this.text(g, value, x + 102, y + 3, WHITE);
      this.hits.add(new Hit(x, y, 100, ROW, action));
   }

   private void drawBottomBar(GuiGraphicsExtractor g, Minecraft mc, int pw) {
      int x0 = pw + 8;
      int y0 = this.height - 26;
      g.fill(x0, y0, this.width - 8, this.height - 6, 0xB0101010);
      int tl = x0 + 8;
      int tr = this.width - 8 - 200;
      int ty = y0 + 6;
      for (int x = tl; x < tr; x += 2) {
         double hour = (x - tl) / (double)(tr - tl) * 24.0;
         int c = 0xFF000000 | sky(hour, 1) << 16 | sky(hour, 2) << 8 | sky(hour, 3);
         g.fill(x, ty, Math.min(tr, x + 2), ty + 9, c);
      }

      for (int mark : new int[]{6, 12, 18}) {
         int mx2 = tl + (int)((tr - tl) * (mark / 24.0));
         g.centeredText(this.font, Component.literal(Integer.toString(mark)), mx2, y0 - 1, GRAY);
      }

      long ticks = mc.level == null ? 0L : VnClock.timeOfDay(mc.level);
      double hourNow = ((ticks / 1000.0) + 6.0) % 24.0;
      int kx = tl + (int)((tr - tl) * (hourNow / 24.0));
      g.fill(kx, ty - 2, kx + 2, ty + 11, WHITE);
      this.text(g, String.format("%02d:%02d", (int)hourNow, (int)((hourNow - (int)hourNow) * 60)), tr + 6, ty + 1, WHITE);
      this.hits.add(new Hit(tl, ty - 2, tr - tl, 13, x -> {
         double h = Math.max(0.0, Math.min(23.99, (x - tl) / (double)(tr - tl) * 24.0));
         long t = Math.round(((h - 6.0 + 24.0) % 24.0) * 1000.0);
         this.command("time set " + t);
      }));
      String[] names = {"Clear", "Rain", "Storm"};
      for (int i = 0; i < 3; i++) {
         final int w = i;
         this.button(g, this.width - 8 - 150 + i * 50, y0 + 4, 48, 14, names[i], false, x -> this.command("weather " + WEATHER[w]));
      }
   }

   private void command(String c) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.getConnection() != null) {
         mc.getConnection().sendCommand(c);
      }
   }

   private void resetTab() {
      for (Row r : this.rows()) {
         if (r.setting() != null) {
            AnsSettings.set(r.setting(), r.setting().defaultValue(), true);
         } else if (r.kind() == 5) {
            ImmersiveVfxSwitch.set(true);
         } else if (r.kind() == 2) {
            Minecraft.getInstance().options.fov().set(70);
         }
      }
   }

   // ------------------------------------------------------------------------------------------------ input

   @Override
   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit h = this.hits.get(i);
         if (this.mx >= h.x() && this.mx < h.x() + h.w() && this.my >= h.y() && this.my < h.y() + h.h()) {
            h.action().accept(this.mx);
            return true;
         }
      }

      return super.mouseClicked(event, doubleClick);
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (mouseX < this.panelWidth()) {
         this.first = Math.max(0, this.first - (int)Math.signum(scrollY));
         return true;
      }

      return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
   }

   @Override
   public void onClose() {
      Minecraft.getInstance().gui.setScreen(this.parent);
   }

   @Override
   public void removed() {
      AnsSettings.save();
      super.removed();
   }
}
